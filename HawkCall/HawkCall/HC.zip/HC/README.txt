If you are reading this, then you have successfully downloaded HawkCall. 
In order to get started, you need to do these things:
	1)Open the Server folder, then open the dist folder, then open Server.jar
	2)Open the Client folder, then open the dist folder, then open Client.jar
Have fun talking anonymously!
-Josh